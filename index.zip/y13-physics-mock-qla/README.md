# Y13 Physics Mock QLA

Question-level analysis for three Y13 AQA A-level Physics (7408) mock papers:

| Paper | Marks | Structure |
|---|---|---|
| Paper 1 | 85 | Q1–7 written (60), Q8–32 multiple choice (25) |
| Paper 2 | 85 | Q1–6 written (60), Q7–31 multiple choice (25) |
| Paper 3 (Section A) | 45 | Q1–3 practical skills and data analysis |

- `/`: student page. Students choose a paper, enter their name, class and class code, and type their marks. They see their own score, percentage, estimated grade, topic profile and to-do list.
- `/teacher`: password-protected dashboard with a student table, topic heat map, question facility, CSV export, class codes and grade boundaries.

Built as a Cloudflare Worker (TypeScript) with a D1 database. **See `DEPLOY.md` for click-by-click setup.**

| File | Contents |
|---|---|
| `src/index.ts` | Router, API, sessions, security headers |
| `src/marking.ts` | Validation, grades, topic profile, to-do list |
| `src/data.ts` | Question blueprint, generated from the mock papers and AQA mark schemes (each part tagged to a 7408 spec topic and AO) |
| `src/pages/` | Student and teacher pages, CSS, browser scripts |

Local testing (needs Node 22+): `npm install`, create `.dev.vars` containing `TEACHER_PASSWORD=test`, then `npm run dev`.
