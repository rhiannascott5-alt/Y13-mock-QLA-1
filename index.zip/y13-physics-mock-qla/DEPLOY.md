# Y13 Physics Mock QLA: how to put it online

This is the question-level analysis (QLA) website for your three Y13 A-level Physics mock papers
(Paper 1, Paper 2 and Paper 3 Section A).

- **Students** go to the main link. They choose a paper, type their name, choose their class (13A2 or 13A4)
  and enter their class code. Then they type their marks. They immediately see their score, percentage,
  estimated grade, topic profile and a to-do list. They only ever see their own result.
- **You** go to the main link with `/teacher` on the end and sign in with your password. You can see every
  student, a topic heat map and a question analysis, and download a CSV for Excel.

It takes about 20 minutes to set up. You need two free accounts: **GitHub** stores the code, and
**Cloudflare** runs the website and stores the results. You only click in your web browser, with no
programs to install.

> **Before you start:** check with your school's data-protection lead that student names and marks may be
> stored in your own Cloudflare account. The site only collects a student's name, class and marks.

---

## Part 1: put the code on GitHub (about 5 minutes)

1. Go to **https://github.com/signup** and create a free account (or sign in).
2. Click the **+** at the top right, then **New repository**.
   - **Repository name:** `y13-physics-mock-qla`
   - Choose **Private**. This is important: the code contains the question list.
   - Click **Create repository**.
3. On the next page, click the link **uploading an existing file**.
4. On your computer, **unzip** `y13-physics-mock-qla.zip`. Open the folder, select **everything inside it**
   (the `src` folder, `package.json`, `package-lock.json`, `wrangler.jsonc`, `tsconfig.json`, `DEPLOY.md`,
   `README.md`) and drag it all onto the GitHub page.
   - Drag the *contents* of the folder, not the zip file and not the folder itself.
   - Check that the `src` folder uploaded with its `pages` folder inside.
5. Click **Commit changes**.

**Never upload a file containing your password.** You only ever type the password into Cloudflare, in Part 2.

---

## Part 2: run it on Cloudflare (about 15 minutes)

### 2.1 Create the account
1. Go to **https://dash.cloudflare.com/sign-up** and create a free account. Confirm your email address.

### 2.2 Connect GitHub and deploy
1. In the Cloudflare dashboard, open **Workers & Pages** (in the left menu, under *Compute*).
2. Click **Create**, then on the **Workers** tab choose **Import a repository**.
3. Click **Connect GitHub**, sign in to GitHub, and allow Cloudflare to access
   **only** the `y13-physics-mock-qla` repository. Then pick that repository.
4. On the settings page, leave everything as it is:
   - **Project name:** `y13-physics-mock-qla`
   - **Deploy command:** `npx wrangler deploy`
5. Click **Deploy**. Wait for **Success** (1 to 3 minutes).
   - The first deploy also **creates the database automatically** (`y13-physics-mock-qla-db`).
   - Your site address appears at the top, for example
     `https://y13-physics-mock-qla.yourname.workers.dev`. Write it down.

<details>
<summary><b>Only if the deploy fails with a message about the database</b> (click to open)</summary>

1. Go to **Storage & databases → D1 SQL Database → Create**, name it `y13-physics-mock-qla-db`, and click **Create**.
2. Copy its **Database ID** (a long code like `1a2b3c4d-...`).
3. On GitHub, open `wrangler.jsonc`, click the pencil (Edit), and change the database line to:
   ```
   { "binding": "DB", "database_name": "y13-physics-mock-qla-db", "database_id": "PASTE-THE-ID-HERE" }
   ```
4. Click **Commit changes**. Cloudflare redeploys by itself within a minute or two.
</details>

### 2.3 Check the database is linked
1. Open your Worker (**Workers & Pages → y13-physics-mock-qla**), then **Settings → Bindings**.
2. You should see **D1 database: DB → y13-physics-mock-qla-db**. If it's there, there's nothing to do.

### 2.4 Set your teacher password
1. Still in the Worker, go to **Settings → Variables and Secrets → Add**.
2. Set **Type** to **Secret**, **Variable name** to `TEACHER_PASSWORD` (exactly like this),
   and **Value** to a strong password of **at least 12 characters**. Keep it somewhere safe.
3. Click **Deploy** (or **Save and deploy**).

Nobody else, Claude included, needs to know this password. To change it later, edit this secret and deploy again.

### 2.5 Test it (2 minutes)
1. Open your site address with **`/teacher`** on the end, e.g. `https://y13-physics-mock-qla.yourname.workers.dev/teacher`.
2. Sign in with your password, then open the **Classes** tab. You should see **13A2** and **13A4**.
   Click **Show** to see each class's 6-character code.
3. In another tab, open the main site address. Choose a paper, type the name `Test Student`,
   choose 13A2, enter its code, fill in some marks and submit. You should see a result.
4. Back on the teacher dashboard, check that *Test Student* appears, then click **Delete** next to it.

### 2.6 Share it with students
Share the main link and each class's code only **after the mock has been sat and marked**, for example
on the board or in Teams/Classroom. Students need the code that matches their own class.

| Class | Code |
|---|---|
| 13A2 | *(see Classes tab)* |
| 13A4 | *(see Classes tab)* |

The codes are created at random when the site first starts, so look them up in the **Classes** tab.

---

## Using the teacher dashboard

- **Paper buttons** (Paper 1 / Paper 2 / Paper 3): each paper is analysed separately.
- **Class menu**: one class or all classes.
- **Overview**: number of students, average percentage and mark, and grade distribution.
- **Students table**: click a column heading to sort, and click a student to see their full result,
  including the to-do list they were shown. **Delete** removes one student's entry for that paper.
- **Topic heat map**: each student's percentage per spec topic, with a class-average row.
  Green is 70%+, amber 40–69%, red below 40%.
- **Question analysis**: average mark and **facility** (average ÷ marks available) for every question part,
  with its AO and original AQA source. Click **Facility** to sort and see what to re-teach first.
- **Download CSV**: opens in Excel, with one row per student, topic percentages and every question mark.
- **Print**: prints the current view.
- **Delete all…**: choose one class first. This deletes every result for that **paper and class only**.
  You must type `DELETE`, and you can download a CSV first.

**Classes tab:** show or copy codes, make a **New code** (the old one stops working), **Close** a class
to stop submissions, **Delete results** for a class (all papers), **Remove class**, or **Add a class**.

**Settings tab:** grade boundaries for each paper, as percentages. The defaults are the 2023–2025 average
of AQA's whole A-level boundaries: A* 70, A 56, B 47, C 37, D 28, E 18. AQA doesn't publish boundaries for
single papers, so these are an estimate. Change them and click **Save**; every grade updates straight away.

## Updating it later
Change or upload files on GitHub and Cloudflare redeploys automatically within a minute or two.
For a different assessment, ask Claude to regenerate `src/data.ts` from the new paper. Then either
use **Delete all** for each class, or start a new repository and Worker, so results stay separate.

## Good to know
- Students sign in with a name and class code, not a personal password, so a student could type a
  classmate's name. If a student resubmits a paper, the new marks replace the old ones. Every submission
  is also kept in a backup log.
- If results are deleted by mistake, go to **Storage & databases → D1 → y13-physics-mock-qla-db → Console**
  and run `SELECT * FROM submission_log ORDER BY id DESC LIMIT 100;` to see the backup copies (read-only).
  Ask Claude to help you restore the rows you need. D1 *Time Travel* can also restore the database to an
  earlier point in the last 30 days.
- Sign-in is locked for 15 minutes after 8 wrong passwords from the same connection.
- Cloudflare's free plan comfortably covers class use.
