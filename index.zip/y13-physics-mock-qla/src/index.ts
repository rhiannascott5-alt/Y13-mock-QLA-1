import { BLUEPRINT } from './data';
import { analyse, cleanBoundaries, cleanName, defaultBoundaries, PAPER_IDS, questionsFor, validateMarks, Boundaries } from './marking';
import studentHtml from './pages/student.html';
import teacherHtml from './pages/teacher.html';
import css from './pages/app.css';
import sharedJs from './pages/shared.client.js';
import studentJs from './pages/student.client.js';
import teacherJs from './pages/teacher.client.js';

export interface Env {
  DB: D1Database;
  TEACHER_PASSWORD?: string;
}

const INITIAL_CLASSES = ['13A2', '13A4'];
const SESSION_HOURS = 12;
const MAX_FAILURES = 8;
const LOCK_MINUTES = 15;
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// ---------------------------------------------------------------- responses & headers
const SECURITY_HEADERS: Record<string, string> = {
  'Content-Security-Policy':
    "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Robots-Tag': 'noindex, nofollow',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Strict-Transport-Security': 'max-age=31536000',
};

function withHeaders(body: BodyInit | null, init: ResponseInit & { headers?: Record<string, string> }): Response {
  return new Response(body, { ...init, headers: { ...SECURITY_HEADERS, ...(init.headers ?? {}) } });
}
function json(data: unknown, status = 200, extra: Record<string, string> = {}): Response {
  return withHeaders(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra } });
}
const err = (message: string, status = 400) => json({ error: message }, status);
function asset(body: string, type: string): Response {
  return withHeaders(body, { status: 200, headers: { 'Content-Type': type, 'Cache-Control': 'no-cache' } });
}

// ---------------------------------------------------------------- crypto helpers
const enc = new TextEncoder();
async function sha256(s: string): Promise<string> {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
async function safeEqual(a: string, b: string): Promise<boolean> {
  // hash first so lengths are equal, then compare every byte
  const [x, y] = await Promise.all([crypto.subtle.digest('SHA-256', enc.encode(a)), crypto.subtle.digest('SHA-256', enc.encode(b))]);
  const ua = new Uint8Array(x), ub = new Uint8Array(y);
  let diff = 0;
  for (let i = 0; i < ua.length; i++) diff |= ua[i] ^ ub[i];
  return diff === 0;
}
function randomToken(bytes = 32): string {
  const a = crypto.getRandomValues(new Uint8Array(bytes));
  return [...a].map((b) => b.toString(16).padStart(2, '0')).join('');
}
function randomCode(len = 6): string {
  const a = crypto.getRandomValues(new Uint8Array(len));
  return [...a].map((b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join('');
}

// ---------------------------------------------------------------- database
let schemaReady = false;
async function ensureSchema(env: Env): Promise<void> {
  if (schemaReady) return;
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS classes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, code TEXT NOT NULL UNIQUE, open INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS submissions (id INTEGER PRIMARY KEY AUTOINCREMENT, paper TEXT NOT NULL, student TEXT NOT NULL, student_key TEXT NOT NULL, class_id INTEGER NOT NULL, marks TEXT NOT NULL, total INTEGER NOT NULL, updated TEXT NOT NULL, UNIQUE (paper, student_key, class_id))`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS submission_log (id INTEGER PRIMARY KEY AUTOINCREMENT, paper TEXT NOT NULL, student TEXT NOT NULL, class_id INTEGER NOT NULL, class_name TEXT NOT NULL, marks TEXT NOT NULL, total INTEGER NOT NULL, created TEXT NOT NULL)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, expires INTEGER NOT NULL)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS login_failures (ip_hash TEXT PRIMARY KEY, count INTEGER NOT NULL, first INTEGER NOT NULL, locked_until INTEGER NOT NULL DEFAULT 0)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`),
  ]);
  const seeded = await env.DB.prepare(`SELECT value FROM settings WHERE key = 'seeded'`).first<{ value: string }>();
  if (!seeded) {
    const now = new Date().toISOString();
    const stmts = INITIAL_CLASSES.map((name) =>
      env.DB.prepare(`INSERT OR IGNORE INTO classes (name, code, open, created) VALUES (?, ?, 1, ?)`).bind(name, randomCode(), now),
    );
    stmts.push(env.DB.prepare(`INSERT OR REPLACE INTO settings (key, value) VALUES ('seeded', '1')`));
    await env.DB.batch(stmts);
  }
  schemaReady = true;
}

async function getBoundaries(env: Env): Promise<Boundaries> {
  const row = await env.DB.prepare(`SELECT value FROM settings WHERE key = 'boundaries'`).first<{ value: string }>();
  if (!row) return defaultBoundaries();
  try {
    const c = cleanBoundaries(JSON.parse(row.value));
    return typeof c === 'string' ? defaultBoundaries() : c;
  } catch {
    return defaultBoundaries();
  }
}

// ---------------------------------------------------------------- auth
function clientIp(req: Request): string {
  return req.headers.get('CF-Connecting-IP') ?? 'local';
}
function getCookie(req: Request, name: string): string | null {
  const h = req.headers.get('Cookie') ?? '';
  for (const part of h.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return v.join('=');
  }
  return null;
}
async function isTeacher(req: Request, env: Env): Promise<boolean> {
  const tok = getCookie(req, 'qla_session');
  if (!tok || !/^[0-9a-f]{64}$/.test(tok)) return false;
  const row = await env.DB.prepare(`SELECT expires FROM sessions WHERE token_hash = ?`).bind(await sha256(tok)).first<{ expires: number }>();
  return !!row && row.expires > Date.now();
}
function isLocal(req: Request): boolean {
  return ['localhost', '127.0.0.1'].includes(new URL(req.url).hostname);
}
function sessionCookie(req: Request, token: string, maxAge: number): string {
  // "Secure" everywhere except local testing over plain http
  return `qla_session=${token}; Path=/; HttpOnly;${isLocal(req) ? '' : ' Secure;'} SameSite=Strict; Max-Age=${maxAge}`;
}

async function login(req: Request, env: Env): Promise<Response> {
  const secret = env.TEACHER_PASSWORD ?? '';
  if (secret.length < 12 && !(secret.length > 0 && isLocal(req))) {
    return err('The teacher password has not been set up yet (it must be at least 12 characters). See DEPLOY.md step 5.', 503);
  }
  const ipHash = await sha256('ip:' + clientIp(req));
  const now = Date.now();
  const f = await env.DB.prepare(`SELECT count, first, locked_until FROM login_failures WHERE ip_hash = ?`).bind(ipHash).first<{ count: number; first: number; locked_until: number }>();
  if (f && f.locked_until > now) {
    const mins = Math.ceil((f.locked_until - now) / 60000);
    return err(`Too many attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}.`, 429);
  }
  let body: { password?: unknown };
  try { body = await req.json(); } catch { return err('Invalid request.'); }
  const pw = typeof body.password === 'string' ? body.password.slice(0, 200) : '';
  if (!(await safeEqual(pw, secret))) {
    const windowStart = f && now - f.first < LOCK_MINUTES * 60000 ? f.first : now;
    const count = f && windowStart === f.first ? f.count + 1 : 1;
    const locked = count >= MAX_FAILURES ? now + LOCK_MINUTES * 60000 : 0;
    await env.DB.prepare(`INSERT OR REPLACE INTO login_failures (ip_hash, count, first, locked_until) VALUES (?, ?, ?, ?)`).bind(ipHash, locked ? 0 : count, windowStart, locked).run();
    return err('Incorrect password.', 401);
  }
  await env.DB.batch([
    env.DB.prepare(`DELETE FROM login_failures WHERE ip_hash = ?`).bind(ipHash),
    env.DB.prepare(`DELETE FROM sessions WHERE expires < ?`).bind(now),
  ]);
  const token = randomToken();
  await env.DB.prepare(`INSERT INTO sessions (token_hash, expires) VALUES (?, ?)`).bind(await sha256(token), now + SESSION_HOURS * 3600000).run();
  return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie(req, token, SESSION_HOURS * 3600) });
}

async function logout(req: Request, env: Env): Promise<Response> {
  const tok = getCookie(req, 'qla_session');
  if (tok) await env.DB.prepare(`DELETE FROM sessions WHERE token_hash = ?`).bind(await sha256(tok)).run();
  return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie(req, '', 0) });
}

// ---------------------------------------------------------------- student API
function publicBlueprint() {
  return {
    title: BLUEPRINT.title,
    subtitle: BLUEPRINT.subtitle,
    papers: BLUEPRINT.papers,
    topics: BLUEPRINT.topics,
    questions: BLUEPRINT.questions.map((q) => ({ paper: q.paper, label: q.label, q: q.q, part: q.part, topic: q.topic, marks: q.marks, mcq: q.mcq })),
  };
}

async function readJson(req: Request): Promise<Record<string, unknown> | null> {
  if (!(req.headers.get('Content-Type') ?? '').includes('application/json')) return null;
  const text = await req.text();
  if (text.length > 20000) return null;
  try {
    const v = JSON.parse(text);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
  } catch {
    return null;
  }
}

async function checkClass(env: Env, classId: unknown, code: unknown): Promise<{ id: number; name: string } | string> {
  const id = Number(classId);
  if (!Number.isInteger(id) || id <= 0) return 'Please choose your class.';
  if (typeof code !== 'string' || code.trim().length === 0 || code.length > 20) return 'Please enter your class code.';
  const row = await env.DB.prepare(`SELECT id, name, code, open FROM classes WHERE id = ?`).bind(id).first<{ id: number; name: string; code: string; open: number }>();
  if (!row) return 'Please choose your class.';
  if (!(await safeEqual(code.trim().toUpperCase(), row.code))) return 'That class code is not right. Check it with your teacher.';
  if (!row.open) return 'Your class is not accepting submissions at the moment.';
  return { id: row.id, name: row.name };
}

async function submit(req: Request, env: Env): Promise<Response> {
  const body = await readJson(req);
  if (!body) return err('Invalid request.');
  const paper = String(body.paper ?? '');
  if (!PAPER_IDS.includes(paper)) return err('Please choose a paper.');
  const name = cleanName(body.name);
  if (!name) return err('Please enter your full name (2 to 60 characters).');
  const cls = await checkClass(env, body.classId, body.code);
  if (typeof cls === 'string') return err(cls, 403);
  const marks = validateMarks(paper, body.marks);
  if (typeof marks === 'string') return err(marks);
  const bounds = await getBoundaries(env);
  const result = analyse(paper, marks, bounds);
  const now = new Date().toISOString();
  const m = JSON.stringify(marks);
  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO submissions (paper, student, student_key, class_id, marks, total, updated) VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT (paper, student_key, class_id) DO UPDATE SET student = excluded.student, marks = excluded.marks, total = excluded.total, updated = excluded.updated`,
    ).bind(paper, name, name.toLowerCase(), cls.id, m, result.total, now),
    env.DB.prepare(`INSERT INTO submission_log (paper, student, class_id, class_name, marks, total, created) VALUES (?, ?, ?, ?, ?, ?, ?)`).bind(paper, name, cls.id, cls.name, m, result.total, now),
  ]);
  return json({ ok: true, name, className: cls.name, result });
}

// ---------------------------------------------------------------- teacher API
async function listClasses(env: Env) {
  const r = await env.DB.prepare(
    `SELECT c.id, c.name, c.code, c.open, (SELECT COUNT(*) FROM submissions s WHERE s.class_id = c.id) AS submissions FROM classes c ORDER BY c.name`,
  ).all<{ id: number; name: string; code: string; open: number; submissions: number }>();
  return r.results;
}

async function results(url: URL, env: Env): Promise<Response> {
  const paper = url.searchParams.get('paper') ?? '';
  if (!PAPER_IDS.includes(paper)) return err('Unknown paper.');
  const cls = url.searchParams.get('class') ?? 'all';
  const bounds = await getBoundaries(env);
  const q = cls === 'all'
    ? env.DB.prepare(`SELECT s.id, s.student, s.class_id, c.name AS class_name, s.marks, s.total, s.updated FROM submissions s JOIN classes c ON c.id = s.class_id WHERE s.paper = ? ORDER BY s.student`).bind(paper)
    : env.DB.prepare(`SELECT s.id, s.student, s.class_id, c.name AS class_name, s.marks, s.total, s.updated FROM submissions s JOIN classes c ON c.id = s.class_id WHERE s.paper = ? AND s.class_id = ? ORDER BY s.student`).bind(paper, Number(cls));
  const rows = (await q.all<{ id: number; student: string; class_id: number; class_name: string; marks: string; total: number; updated: string }>()).results;
  const students = rows.map((r) => {
    const marks = JSON.parse(r.marks) as Record<string, number>;
    return { id: r.id, student: r.student, classId: r.class_id, className: r.class_name, updated: r.updated, marks, result: analyse(paper, marks, bounds) };
  });
  return json({ paper, students, questions: questionsFor(paper) });
}

async function teacherApi(req: Request, url: URL, env: Env, path: string): Promise<Response> {
  const method = req.method;
  if (path === '/api/teacher/blueprint' && method === 'GET') {
    return json({ ...BLUEPRINT, boundaries: await getBoundaries(env), classes: await listClasses(env) });
  }
  if (path === '/api/teacher/results' && method === 'GET') return results(url, env);
  if (path === '/api/teacher/classes' && method === 'GET') return json({ classes: await listClasses(env) });
  if (path === '/api/teacher/classes' && method === 'POST') {
    const body = await readJson(req);
    const name = typeof body?.name === 'string' ? body.name.replace(/[^A-Za-z0-9 _\-\/]/g, '').trim() : '';
    if (name.length < 1 || name.length > 30) return err('Class name must be 1 to 30 letters, numbers, spaces or - _ /');
    try {
      await env.DB.prepare(`INSERT INTO classes (name, code, open, created) VALUES (?, ?, 1, ?)`).bind(name, randomCode(), new Date().toISOString()).run();
    } catch {
      return err('A class with that name already exists.');
    }
    return json({ classes: await listClasses(env) });
  }
  let m = path.match(/^\/api\/teacher\/classes\/(\d+)\/(regenerate|open|close|delete-results|delete)$/);
  if (m && method === 'POST') {
    const id = Number(m[1]);
    const exists = await env.DB.prepare(`SELECT id FROM classes WHERE id = ?`).bind(id).first();
    if (!exists) return err('Class not found.', 404);
    if (m[2] === 'regenerate') await env.DB.prepare(`UPDATE classes SET code = ? WHERE id = ?`).bind(randomCode(), id).run();
    if (m[2] === 'open') await env.DB.prepare(`UPDATE classes SET open = 1 WHERE id = ?`).bind(id).run();
    if (m[2] === 'close') await env.DB.prepare(`UPDATE classes SET open = 0 WHERE id = ?`).bind(id).run();
    if (m[2] === 'delete-results' || m[2] === 'delete') {
      const body = await readJson(req);
      if (body?.confirm !== 'DELETE') return err('Type DELETE to confirm.');
      await env.DB.prepare(`DELETE FROM submissions WHERE class_id = ?`).bind(id).run();
      if (m[2] === 'delete') await env.DB.prepare(`DELETE FROM classes WHERE id = ?`).bind(id).run();
    }
    return json({ classes: await listClasses(env) });
  }
  m = path.match(/^\/api\/teacher\/submissions\/(\d+)\/delete$/);
  if (m && method === 'POST') {
    await env.DB.prepare(`DELETE FROM submissions WHERE id = ?`).bind(Number(m[1])).run();
    return json({ ok: true });
  }
  if (path === '/api/teacher/delete-all' && method === 'POST') {
    const body = await readJson(req);
    const paper = String(body?.paper ?? '');
    const classId = Number(body?.classId);
    if (!PAPER_IDS.includes(paper)) return err('Unknown paper.');
    if (!Number.isInteger(classId) || classId <= 0) return err('Choose a single class before using Delete all.');
    if (body?.confirm !== 'DELETE') return err('Type DELETE to confirm.');
    const r = await env.DB.prepare(`DELETE FROM submissions WHERE paper = ? AND class_id = ?`).bind(paper, classId).run();
    return json({ ok: true, deleted: r.meta.changes ?? 0 });
  }
  if (path === '/api/teacher/settings' && method === 'POST') {
    const body = await readJson(req);
    const b = body?.reset === true ? defaultBoundaries() : cleanBoundaries(body?.boundaries);
    if (typeof b === 'string') return err(b);
    await env.DB.prepare(`INSERT OR REPLACE INTO settings (key, value) VALUES ('boundaries', ?)`).bind(JSON.stringify(b)).run();
    return json({ boundaries: b });
  }
  return err('Not found.', 404);
}

// ---------------------------------------------------------------- router
export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    try {
      if (req.method === 'GET' || req.method === 'HEAD') {
        if (path === '/') return asset(studentHtml, 'text/html; charset=utf-8');
        if (path === '/teacher') return asset(teacherHtml, 'text/html; charset=utf-8');
        if (path === '/static/app.css') return asset(css, 'text/css; charset=utf-8');
        if (path === '/static/shared.js') return asset(sharedJs, 'text/javascript; charset=utf-8');
        if (path === '/static/student.js') return asset(studentJs, 'text/javascript; charset=utf-8');
        if (path === '/static/teacher.js') return asset(teacherJs, 'text/javascript; charset=utf-8');
        if (path === '/robots.txt') return asset('User-agent: *\nDisallow: /\n', 'text/plain');
      }
      if (!path.startsWith('/api/')) return withHeaders('Not found', { status: 404, headers: { 'Content-Type': 'text/plain' } });

      // state-changing requests must come from this site (CSRF defence in addition to SameSite=Strict)
      if (req.method !== 'GET') {
        const origin = req.headers.get('Origin');
        if (origin && origin !== url.origin) return err('Forbidden.', 403);
      }
      if (!env.DB) return err('The database is not connected yet. See DEPLOY.md.', 503);
      await ensureSchema(env);

      if (path === '/api/blueprint' && req.method === 'GET') return json(publicBlueprint());
      if (path === '/api/classes' && req.method === 'GET') {
        const r = await env.DB.prepare(`SELECT id, name FROM classes WHERE open = 1 ORDER BY name`).all();
        return json({ classes: r.results });
      }
      if (path === '/api/check-class' && req.method === 'POST') {
        const body = await readJson(req);
        const c = await checkClass(env, body?.classId, body?.code);
        return typeof c === 'string' ? err(c, 403) : json({ ok: true, className: c.name });
      }
      if (path === '/api/submit' && req.method === 'POST') return submit(req, env);
      if (path === '/api/login' && req.method === 'POST') return login(req, env);
      if (path === '/api/logout' && req.method === 'POST') return logout(req, env);
      if (path === '/api/session' && req.method === 'GET') return json({ signedIn: await isTeacher(req, env) });

      if (path === '/api/results' || path.startsWith('/api/teacher/')) {
        if (!(await isTeacher(req, env))) return err('Please sign in.', 401);
        if (path === '/api/results') return results(url, env);
        return teacherApi(req, url, env, path);
      }
      return err('Not found.', 404);
    } catch (e) {
      console.error(e);
      return err('Something went wrong. Please try again.', 500);
    }
  },
} satisfies ExportedHandler<Env>;
