(function () {
  'use strict';
  var Q = window.QLA, el = Q.el, $ = function (id) { return document.getElementById(id); };
  var BP = null, paper = null, classInfo = null, marks = {}, lastResult = null;
  var topicName = {};

  function draftKey() { return 'qla-draft-' + paper; }

  function init() {
    Promise.all([Q.api('/api/blueprint'), Q.api('/api/classes')]).then(function (res) {
      BP = res[0];
      BP.topics.forEach(function (t) { topicName[t.code] = t.name; });
      $('title').textContent = BP.title;
      $('subtitle').textContent = BP.subtitle;
      BP.papers.forEach(function (p) {
        var b = el('button', { type: 'button', class: 'choice', 'aria-pressed': 'false', 'data-id': p.id, onclick: function () { choosePaper(p.id); } },
          [el('b', { text: p.name }), el('span', { class: 'muted small', text: p.max + ' marks' })]);
        $('papers').appendChild(b);
      });
      var sel = $('class');
      res[1].classes.forEach(function (c) { sel.appendChild(el('option', { value: c.id, text: c.name })); });
      var saved = Q.store('qla-me');
      if (saved) { $('name').value = saved.name || ''; if (saved.classId) sel.value = String(saved.classId); }
    }).catch(function (e) { Q.message($('start-msg'), e.message); });

    $('continue').addEventListener('click', start);
    $('back').addEventListener('click', function () { Q.show($('entry'), false); Q.show($('start'), true); });
    $('submit').addEventListener('click', submit);
    $('edit').addEventListener('click', function () { Q.show($('result'), false); Q.show($('entry'), true); window.scrollTo(0, 0); });
    $('another').addEventListener('click', function () { Q.show($('result'), false); Q.show($('start'), true); paper = null; markPaperButtons(); window.scrollTo(0, 0); });
    $('print').addEventListener('click', function () { window.print(); });
  }

  function markPaperButtons() {
    Array.prototype.forEach.call($('papers').children, function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-id') === paper ? 'true' : 'false'); });
  }
  function choosePaper(id) { paper = id; markPaperButtons(); }

  function start() {
    var msg = $('start-msg');
    var name = $('name').value.trim(), classId = $('class').value, code = $('code').value.trim();
    if (!paper) return Q.message(msg, 'Please choose which paper you are entering marks for.');
    if (name.length < 2) return Q.message(msg, 'Please enter your full name.');
    if (!classId) return Q.message(msg, 'Please choose your class.');
    if (!code) return Q.message(msg, 'Please enter your class code.');
    $('continue').disabled = true;
    Q.api('/api/check-class', { method: 'POST', body: { classId: Number(classId), code: code } }).then(function (r) {
      Q.message(msg, '');
      classInfo = { id: Number(classId), name: r.className, code: code, student: name };
      Q.store('qla-me', { name: name, classId: Number(classId) });
      buildForm();
      Q.show($('start'), false); Q.show($('entry'), true); window.scrollTo(0, 0);
    }).catch(function (e) { Q.message(msg, e.message); }).then(function () { $('continue').disabled = false; });
  }

  function buildForm() {
    var p = BP.papers.find(function (x) { return x.id === paper; });
    $('entry-title').textContent = '2. Enter your marks – ' + p.name;
    $('paper-max').textContent = p.max;
    var qs = BP.questions.filter(function (q) { return q.paper === paper; });
    marks = Q.store(draftKey()) || {};
    var form = Q.clear($('form'));
    var written = qs.filter(function (q) { return !q.mcq; }), mcq = qs.filter(function (q) { return q.mcq; });
    if (written.length) {
      form.appendChild(el('h3', { text: mcq.length ? 'Section A – written questions' : 'Questions' }));
      var groups = {};
      var order = [];
      written.forEach(function (q) { if (!groups[q.q]) { groups[q.q] = []; order.push(q.q); } groups[q.q].push(q); });
      order.forEach(function (n) {
        var g = el('div', { class: 'qgroup' }, [el('h4', { text: 'Question ' + n })]);
        groups[n].forEach(function (q) { g.appendChild(writtenRow(q)); });
        form.appendChild(g);
      });
    }
    if (mcq.length) {
      form.appendChild(el('h3', { text: 'Section B – multiple choice (1 mark each)' }));
      var g2 = el('div', { class: 'qgroup' });
      mcq.forEach(function (q) { g2.appendChild(mcqRow(q)); });
      form.appendChild(g2);
    }
    updateTotal();
  }

  function writtenRow(q) {
    var input = el('input', { type: 'number', inputmode: 'numeric', min: 0, max: q.marks, step: 1, 'aria-label': 'Mark for question ' + q.label, id: 'm-' + q.label });
    if (marks[q.label] !== undefined) input.value = marks[q.label];
    input.addEventListener('input', function () {
      var v = input.value.trim();
      var n = Number(v);
      var ok = v === '' || (Number.isInteger(n) && n >= 0 && n <= q.marks);
      input.classList.toggle('bad', !ok);
      if (v === '' || !ok) delete marks[q.label]; else marks[q.label] = n;
      saveDraft(); updateTotal();
    });
    return el('div', { class: 'qrow' }, [
      el('div', { class: 'lab', text: q.label }),
      el('div', { class: 'topic', text: topicName[q.topic] || '' }),
      el('div', { class: 'entry' }, [input, el('span', { class: 'muted', text: '/ ' + q.marks })]),
    ]);
  }

  function mcqRow(q) {
    var wrong = el('button', { type: 'button', class: 'wrong', 'aria-pressed': 'false', 'aria-label': 'Question ' + q.label + ' wrong', text: '✗ 0' });
    var right = el('button', { type: 'button', class: 'right', 'aria-pressed': 'false', 'aria-label': 'Question ' + q.label + ' right', text: '✓ 1' });
    function paint() {
      wrong.setAttribute('aria-pressed', marks[q.label] === 0 ? 'true' : 'false');
      right.setAttribute('aria-pressed', marks[q.label] === 1 ? 'true' : 'false');
    }
    wrong.addEventListener('click', function () { marks[q.label] = 0; paint(); saveDraft(); updateTotal(); });
    right.addEventListener('click', function () { marks[q.label] = 1; paint(); saveDraft(); updateTotal(); });
    paint();
    return el('div', { class: 'qrow' }, [
      el('div', { class: 'lab', text: q.label }),
      el('div', { class: 'topic', text: topicName[q.topic] || '' }),
      el('div', { class: 'entry' }, [el('span', { class: 'seg', id: 'm-' + q.label }, [wrong, right])]),
    ]);
  }

  function saveDraft() { Q.store(draftKey(), marks); }

  function updateTotal() {
    var qs = BP.questions.filter(function (q) { return q.paper === paper; });
    var t = 0, n = 0;
    qs.forEach(function (q) { if (marks[q.label] !== undefined) { t += marks[q.label]; n++; } });
    $('running').textContent = t;
    $('filled').textContent = '(' + n + ' of ' + qs.length + ' entered)';
  }

  function submit() {
    var msg = $('entry-msg');
    var qs = BP.questions.filter(function (q) { return q.paper === paper; });
    var missing = qs.filter(function (q) { return marks[q.label] === undefined; });
    if (missing.length) {
      Q.message(msg, 'Please enter a mark for every question. Missing: ' + missing.slice(0, 8).map(function (q) { return q.label; }).join(', ') + (missing.length > 8 ? '…' : '') + '. Enter 0 if you scored nothing.');
      var first = document.getElementById('m-' + missing[0].label);
      if (first) first.scrollIntoView({ block: 'center' });
      return;
    }
    $('submit').disabled = true;
    Q.api('/api/submit', { method: 'POST', body: { paper: paper, name: classInfo.student, classId: classInfo.id, code: classInfo.code, marks: marks } })
      .then(function (r) { Q.message(msg, ''); lastResult = r; showResult(r); })
      .catch(function (e) { Q.message(msg, e.message); })
      .then(function () { $('submit').disabled = false; });
  }

  function showResult(r) {
    var res = r.result;
    $('result-title').textContent = 'Your result – ' + res.paperName;
    $('result-who').textContent = r.name + ' • ' + r.className + ' • saved. If you submit this paper again, your new marks replace these.';
    var s = Q.clear($('score'));
    [[res.total + ' / ' + res.max, 'Marks'], [res.pct + '%', 'Percentage'], [res.grade, 'Estimated grade']].forEach(function (x) {
      s.appendChild(el('div', { class: 'stat' }, [el('div', { class: 'v', text: x[0] }), el('div', { class: 'k', text: x[1] })]));
    });
    var t = Q.clear($('topics'));
    res.topics.forEach(function (tp) { t.appendChild(Q.bar(tp.name, 'Spec ' + tp.spec, tp.pct, tp.rag, tp.got + '/' + tp.max + ' • ' + Math.round(tp.pct) + '%')); });
    var todo = Q.clear($('todo'));
    if (!res.todo.length) todo.appendChild(el('li', {}, [el('div', { class: 'box' }), el('div', {}, [el('b', { text: 'Excellent work!' }), el('span', { text: 'You did not drop marks anywhere significant. Try some harder past-paper questions.' })])]));
    res.todo.forEach(function (item) {
      todo.appendChild(el('li', {}, [el('div', { class: 'box', 'aria-hidden': 'true' }), el('div', {}, [el('b', { text: item.text }), el('span', { text: item.detail })])]));
    });
    $('grade-note').textContent = 'The estimated grade uses recent AQA A-level Physics grade boundaries applied to this paper. It is a guide, not a prediction.';
    Q.show($('entry'), false); Q.show($('result'), true); window.scrollTo(0, 0);
  }

  document.addEventListener('DOMContentLoaded', init);
})();
