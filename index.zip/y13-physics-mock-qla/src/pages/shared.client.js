/* Shared helpers. All text is set with textContent, never innerHTML. */
(function () {
  'use strict';
  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === undefined || v === null || v === false) return;
        if (k === 'text') n.textContent = String(v);
        else if (k === 'class') n.className = v;
        else if (k.slice(0, 2) === 'on') n.addEventListener(k.slice(2), v);
        else if (k === 'style') Object.assign(n.style, v);
        else n.setAttribute(k, v === true ? '' : String(v));
      });
    }
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      n.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
    });
    return n;
  }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
  function api(path, opts) {
    opts = opts || {};
    var init = { method: opts.method || 'GET', headers: {}, credentials: 'same-origin' };
    if (opts.body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
    return fetch(path, init).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (!r.ok) { var e = new Error(data.error || ('Request failed (' + r.status + ')')); e.status = r.status; throw e; }
        return data;
      });
    });
  }
  function show(n, on) { n.classList.toggle('hidden', !on); }
  function message(n, text, kind) { n.textContent = text || ''; n.className = 'msg ' + (kind || 'error') + (text ? '' : ' hidden'); }
  function store(key, value) {
    try { if (value === undefined) return JSON.parse(localStorage.getItem(key) || 'null'); localStorage.setItem(key, JSON.stringify(value)); } catch (e) { return null; }
    return null;
  }
  function bar(name, sub, pct, rag, valText) {
    return el('div', { class: 'bar' }, [
      el('div', { class: 'name' }, [name, sub ? el('small', { text: sub }) : null]),
      el('div', { class: 'track', role: 'img', 'aria-label': name + ' ' + pct + '%' }, [el('div', { class: 'fill ' + rag, style: { width: Math.max(2, Math.min(100, pct)) + '%' } })]),
      el('div', { class: 'val', text: valText }),
    ]);
  }
  window.QLA = { el: el, clear: clear, api: api, show: show, message: message, store: store, bar: bar };
})();
