(function () {
  'use strict';
  var Q = window.QLA, el = Q.el, $ = function (id) { return document.getElementById(id); };
  var BP = null, paper = null, classFilter = 'all', data = null;
  var sortState = { students: { key: 'student', dir: 1 }, questions: { key: 'label', dir: 1 } };
  var topicByCode = {};

  // ------------------------------------------------------------ sign in
  function init() {
    $('signin').addEventListener('click', signIn);
    $('pw').addEventListener('keydown', function (e) { if (e.key === 'Enter') signIn(); });
    $('logout').addEventListener('click', function () { Q.api('/api/logout', { method: 'POST', body: {} }).then(function () { location.reload(); }); });
    $('dlg-close').addEventListener('click', function () { $('dlg').close(); });
    Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) { b.addEventListener('click', function () { tab(b.getAttribute('data-tab')); }); });
    $('class-filter').addEventListener('change', function () { classFilter = $('class-filter').value; loadResults(); });
    $('csv').addEventListener('click', downloadCsv);
    $('print').addEventListener('click', function () { window.print(); });
    $('delete-all').addEventListener('click', deleteAll);
    $('add-class').addEventListener('click', addClass);
    $('save-bounds').addEventListener('click', saveBounds);
    $('reset-bounds').addEventListener('click', function () { postBounds({ reset: true }); });
    Q.api('/api/session').then(function (s) { if (s.signedIn) boot(); else Q.show($('login'), true); })
      .catch(function (e) { Q.show($('login'), true); Q.message($('login-msg'), e.message); });
  }
  function signIn() {
    $('signin').disabled = true;
    Q.api('/api/login', { method: 'POST', body: { password: $('pw').value } })
      .then(function () { $('pw').value = ''; Q.message($('login-msg'), ''); boot(); })
      .catch(function (e) { Q.message($('login-msg'), e.message); })
      .then(function () { $('signin').disabled = false; });
  }
  function onAuthError(e) {
    if (e.status === 401) { Q.show($('app'), false); Q.show($('logout'), false); Q.show($('login'), true); Q.message($('login-msg'), 'Your session has ended. Please sign in again.'); return true; }
    return false;
  }

  function boot() {
    Q.show($('login'), false);
    Q.api('/api/teacher/blueprint').then(function (bp) {
      BP = bp;
      BP.topics.forEach(function (t) { topicByCode[t.code] = t; });
      $('subtitle').textContent = BP.title + ' – question-level analysis';
      var pills = Q.clear($('paper-pills'));
      BP.papers.forEach(function (p) {
        pills.appendChild(el('button', { type: 'button', 'aria-pressed': 'false', 'data-id': p.id, text: p.name, onclick: function () { setPaper(p.id); } }));
      });
      fillClassFilter(); renderClasses(); renderBounds();
      Q.show($('app'), true); Q.show($('logout'), true);
      setPaper(BP.papers[0].id);
    }).catch(function (e) { if (!onAuthError(e)) Q.message($('login-msg'), e.message); Q.show($('login'), true); });
  }

  function tab(name) {
    ['dash', 'classes', 'settings'].forEach(function (t) { Q.show($('tab-' + t), t === name); });
    Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) { b.setAttribute('aria-selected', b.getAttribute('data-tab') === name ? 'true' : 'false'); });
    if (name === 'dash') loadResults();
  }

  function fillClassFilter() {
    var sel = Q.clear($('class-filter'));
    sel.appendChild(el('option', { value: 'all', text: 'All classes' }));
    BP.classes.forEach(function (c) { sel.appendChild(el('option', { value: String(c.id), text: c.name })); });
    if (classFilter !== 'all' && !BP.classes.some(function (c) { return String(c.id) === classFilter; })) classFilter = 'all';
    sel.value = classFilter;
  }

  function setPaper(id) {
    paper = id;
    Array.prototype.forEach.call($('paper-pills').children, function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-id') === id ? 'true' : 'false'); });
    loadResults();
  }

  // ------------------------------------------------------------ dashboard
  function loadResults() {
    if (!paper) return;
    Q.api('/api/teacher/results?paper=' + encodeURIComponent(paper) + '&class=' + encodeURIComponent(classFilter))
      .then(function (r) { data = r; Q.message($('dash-msg'), ''); renderDash(); })
      .catch(function (e) { if (!onAuthError(e)) Q.message($('dash-msg'), e.message); });
  }

  function paperInfo() { return BP.papers.find(function (p) { return p.id === paper; }); }
  function rag(p) { return p >= 70 ? 'green' : p >= 40 ? 'amber' : 'red'; }
  function round1(x) { return Math.round(x * 10) / 10; }

  function renderDash() {
    var p = paperInfo(), st = data.students;
    var className = classFilter === 'all' ? 'all classes' : (BP.classes.find(function (c) { return String(c.id) === classFilter; }) || {}).name;
    $('dash-title').textContent = p.name + ' – ' + className;
    var avgPct = st.length ? round1(st.reduce(function (a, s) { return a + s.result.pct; }, 0) / st.length) : 0;
    var avgMark = st.length ? round1(st.reduce(function (a, s) { return a + s.result.total; }, 0) / st.length) : 0;
    var h = Q.clear($('headline'));
    [[String(st.length), 'Students submitted'], [st.length ? avgPct + '%' : '–', 'Average percentage'], [st.length ? avgMark + ' / ' + p.max : '–', 'Average mark']].forEach(function (x) {
      h.appendChild(el('div', { class: 'stat' }, [el('div', { class: 'v', text: x[0] }), el('div', { class: 'k', text: x[1] })]));
    });
    var gd = Q.clear($('grade-dist'));
    var grades = BP.boundaries[paper].map(function (b) { return b.grade; }).concat(['U']);
    gd.appendChild(el('b', { class: 'small', text: 'Grade distribution:' }));
    grades.forEach(function (g) {
      var n = st.filter(function (s) { return s.result.grade === g; }).length;
      gd.appendChild(el('span', { text: g + ': ' + n }));
    });
    $('delete-all').disabled = classFilter === 'all' || !st.length;
    $('delete-all').title = classFilter === 'all' ? 'Choose one class first' : '';
    renderStudents(); renderHeat(); renderQuestions();
  }

  function sortRows(rows, state, getters) {
    var g = getters[state.key];
    return rows.slice().sort(function (a, b) {
      var x = g(a), y = g(b);
      if (typeof x === 'string') return state.dir * x.localeCompare(y);
      return state.dir * (x - y);
    });
  }
  function headerRow(tableName, cols, rerender) {
    return el('tr', {}, cols.map(function (c) {
      var th = el('th', { class: (c.sort ? 'sortable ' : '') + (c.num ? 'num' : ''), text: c.label, scope: 'col', title: c.title || null });
      if (c.sort) th.addEventListener('click', function () {
        var s = sortState[tableName];
        if (s.key === c.sort) s.dir = -s.dir; else { s.key = c.sort; s.dir = c.num ? -1 : 1; }
        rerender();
      });
      return th;
    }));
  }

  function renderStudents() {
    var t = Q.clear($('students'));
    var cols = [{ label: 'Student', sort: 'student' }, { label: 'Class', sort: 'className' }, { label: 'Mark', sort: 'total', num: true },
      { label: '%', sort: 'pct', num: true }, { label: 'Grade', sort: 'pct', num: true }, { label: 'Last updated', sort: 'updated' }, { label: '' }];
    t.appendChild(el('thead', {}, [headerRow('students', cols, renderStudents)]));
    var tb = el('tbody');
    if (!data.students.length) tb.appendChild(el('tr', {}, [el('td', { colspan: 7, class: 'muted', text: 'No submissions yet for this paper and class.' })]));
    var rows = sortRows(data.students, sortState.students, {
      student: function (s) { return s.student; }, className: function (s) { return s.className; }, total: function (s) { return s.result.total; },
      pct: function (s) { return s.result.pct; }, updated: function (s) { return s.updated; },
    });
    rows.forEach(function (s) {
      var del = el('button', { type: 'button', class: 'ghost small noprint', text: 'Delete' });
      del.addEventListener('click', function (e) { e.stopPropagation(); deleteStudent(s); });
      var tr = el('tr', { class: 'clickable', tabindex: 0 }, [
        el('td', { text: s.student }), el('td', { text: s.className }), el('td', { class: 'num', text: s.result.total + ' / ' + s.result.max }),
        el('td', { class: 'num', text: s.result.pct + '%' }), el('td', { class: 'num', text: s.result.grade }),
        el('td', { class: 'small muted', text: new Date(s.updated).toLocaleString() }), el('td', {}, [del]),
      ]);
      tr.addEventListener('click', function () { openStudent(s); });
      tr.addEventListener('keydown', function (e) { if (e.key === 'Enter') openStudent(s); });
      tb.appendChild(tr);
    });
    t.appendChild(tb);
  }

  function paperTopics() {
    var seen = {}, list = [];
    data.questions.forEach(function (q) { if (!seen[q.topic]) { seen[q.topic] = true; list.push(q.topic); } });
    return BP.topics.filter(function (t) { return seen[t.code]; });
  }

  function renderHeat() {
    var t = Q.clear($('heat'));
    var topics = paperTopics();
    t.appendChild(el('thead', {}, [el('tr', {}, [el('th', { text: 'Student' })].concat(topics.map(function (tp) {
      return el('th', { class: 'rot', title: tp.name, text: tp.spec + ' ' + shortName(tp.name) });
    })).concat([el('th', { class: 'num', text: 'Total %' })]))]));
    var tb = el('tbody');
    var sums = {};
    sortRows(data.students, { key: 'student', dir: 1 }, { student: function (s) { return s.student; } }).forEach(function (s) {
      var by = {}; s.result.topics.forEach(function (x) { by[x.code] = x; });
      var tr = el('tr', {}, [el('td', { text: s.student })]);
      topics.forEach(function (tp) {
        var x = by[tp.code];
        if (!sums[tp.code]) sums[tp.code] = { got: 0, max: 0 };
        if (x) { sums[tp.code].got += x.got; sums[tp.code].max += x.max; }
        tr.appendChild(el('td', { class: 'cell ' + (x ? x.rag : 'none'), title: x ? tp.name + ': ' + x.got + '/' + x.max : '', text: x ? Math.round(x.pct) : '–' }));
      });
      tr.appendChild(el('td', { class: 'num', text: s.result.pct + '%' }));
      tb.appendChild(tr);
    });
    if (data.students.length) {
      var avg = el('tr', {}, [el('td', {}, [el('b', { text: 'Class average' })])]);
      topics.forEach(function (tp) {
        var sm = sums[tp.code]; var pc = sm && sm.max ? (100 * sm.got) / sm.max : 0;
        avg.appendChild(el('td', { class: 'cell ' + rag(pc), text: Math.round(pc) }));
      });
      var ap = data.students.reduce(function (a, s) { return a + s.result.pct; }, 0) / data.students.length;
      avg.appendChild(el('td', { class: 'num' }, [el('b', { text: round1(ap) + '%' })]));
      tb.appendChild(avg);
    } else tb.appendChild(el('tr', {}, [el('td', { colspan: topics.length + 2, class: 'muted', text: 'No submissions yet.' })]));
    t.appendChild(tb);
  }
  function shortName(n) { return n.length > 22 ? n.slice(0, 20) + '…' : n; }

  function questionStats() {
    var n = data.students.length;
    return data.questions.map(function (q) {
      var sum = 0; data.students.forEach(function (s) { sum += s.marks[q.label] || 0; });
      var avg = n ? sum / n : 0;
      return { q: q, avg: avg, facility: n ? (100 * avg) / q.marks : 0 };
    });
  }

  function renderQuestions() {
    var t = Q.clear($('questions'));
    var cols = [{ label: 'Question', sort: 'label' }, { label: 'Topic', sort: 'topic' }, { label: 'AO', sort: 'ao' }, { label: 'Marks', sort: 'marks', num: true },
      { label: 'Average', sort: 'avg', num: true }, { label: 'Facility', sort: 'facility', num: true }, { label: 'Original source', sort: 'src' }];
    t.appendChild(el('thead', {}, [headerRow('questions', cols, renderQuestions)]));
    var tb = el('tbody');
    var order = {}; data.questions.forEach(function (q, i) { order[q.label] = i; });
    sortRows(questionStats(), sortState.questions, {
      label: function (r) { return order[r.q.label]; }, topic: function (r) { return topicByCode[r.q.topic].spec; }, ao: function (r) { return r.q.ao; },
      marks: function (r) { return r.q.marks; }, avg: function (r) { return r.avg; }, facility: function (r) { return r.facility; }, src: function (r) { return r.q.src; },
    }).forEach(function (r) {
      var tp = topicByCode[r.q.topic];
      tb.appendChild(el('tr', {}, [
        el('td', { text: r.q.label + (r.q.mcq ? ' (MCQ)' : '') }), el('td', { title: tp.name, text: tp.spec + ' ' + shortName(tp.name) }), el('td', { text: r.q.ao }),
        el('td', { class: 'num', text: r.q.marks }), el('td', { class: 'num', text: data.students.length ? round1(r.avg) : '–' }),
        el('td', { class: 'cell ' + (data.students.length ? rag(r.facility) : 'none'), text: data.students.length ? Math.round(r.facility) + '%' : '–' }),
        el('td', { class: 'small muted', text: r.q.src }),
      ]));
    });
    t.appendChild(tb);
  }

  function openStudent(s) {
    var res = s.result;
    $('dlg-title').textContent = s.student + ' – ' + s.className + ' – ' + res.paperName;
    var body = Q.clear($('dlg-body'));
    body.appendChild(el('div', { class: 'score' }, [[res.total + ' / ' + res.max, 'Marks'], [res.pct + '%', 'Percentage'], [res.grade, 'Estimated grade']].map(function (x) {
      return el('div', { class: 'stat' }, [el('div', { class: 'v', text: x[0] }), el('div', { class: 'k', text: x[1] })]);
    })));
    body.appendChild(el('h3', { text: 'Topic profile' }));
    var bars = el('div', { class: 'bars' });
    res.topics.forEach(function (tp) { bars.appendChild(Q.bar(tp.name, 'Spec ' + tp.spec, tp.pct, tp.rag, tp.got + '/' + tp.max)); });
    body.appendChild(bars);
    body.appendChild(el('h3', { text: 'To-do list shown to the student' }));
    var ul = el('ul', { class: 'todo' });
    res.todo.forEach(function (it) { ul.appendChild(el('li', {}, [el('div', { class: 'box' }), el('div', {}, [el('b', { text: it.text }), el('span', { text: it.detail })])])); });
    body.appendChild(ul);
    body.appendChild(el('h3', { text: 'Marks by question' }));
    var tbl = el('table', {}, [el('thead', {}, [el('tr', {}, ['Question', 'Topic', 'Mark', 'Out of'].map(function (h) { return el('th', { text: h }); }))])]);
    var tb = el('tbody');
    data.questions.forEach(function (q) {
      var m = s.marks[q.label] || 0;
      tb.appendChild(el('tr', {}, [el('td', { text: q.label }), el('td', { text: topicByCode[q.topic].name }),
        el('td', { class: 'cell ' + rag((100 * m) / q.marks), text: m }), el('td', { class: 'num', text: q.marks })]));
    });
    tbl.appendChild(tb);
    body.appendChild(el('div', { class: 'tablewrap' }, [tbl]));
    $('dlg').showModal();
  }

  // ------------------------------------------------------------ CSV and deletes
  function csvCell(v) {
    var s = String(v === undefined || v === null ? '' : v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // stop spreadsheet formula injection
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function downloadCsv() {
    if (!data) return;
    var topics = paperTopics();
    var head = ['Student', 'Class', 'Paper', 'Total', 'Max', 'Percent', 'Grade', 'Updated']
      .concat(topics.map(function (t) { return t.spec + ' ' + t.name + ' %'; }))
      .concat(data.questions.map(function (q) { return 'Q' + q.label + ' (/' + q.marks + ')'; }));
    var lines = [head.map(csvCell).join(',')];
    data.students.forEach(function (s) {
      var by = {}; s.result.topics.forEach(function (x) { by[x.code] = x; });
      lines.push([s.student, s.className, s.result.paperName, s.result.total, s.result.max, s.result.pct, s.result.grade, s.updated]
        .concat(topics.map(function (t) { return by[t.code] ? by[t.code].pct : ''; }))
        .concat(data.questions.map(function (q) { return s.marks[q.label]; })).map(csvCell).join(','));
    });
    var blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var a = el('a', { href: URL.createObjectURL(blob), download: 'qla-' + paper + '-' + (classFilter === 'all' ? 'all-classes' : (BP.classes.find(function (c) { return String(c.id) === classFilter; }) || {}).name) + '.csv' });
    document.body.appendChild(a); a.click(); a.remove();
  }

  function deleteStudent(s) {
    if (!window.confirm('Delete ' + s.student + '’s ' + paperInfo().name + ' result? This cannot be undone.')) return;
    Q.api('/api/teacher/submissions/' + s.id + '/delete', { method: 'POST', body: {} }).then(loadResults).catch(function (e) { if (!onAuthError(e)) Q.message($('dash-msg'), e.message); });
  }

  function typedConfirm(title, explain, onConfirm, offerCsv) {
    $('dlg-title').textContent = title;
    var body = Q.clear($('dlg-body'));
    var input = el('input', { type: 'text', autocomplete: 'off', placeholder: 'Type DELETE' });
    var go = el('button', { type: 'button', class: 'danger', text: 'Delete', disabled: true });
    var msg = el('div', { class: 'msg error hidden', role: 'alert' });
    input.addEventListener('input', function () { go.disabled = input.value !== 'DELETE'; });
    go.addEventListener('click', function () { go.disabled = true; onConfirm().then(function () { $('dlg').close(); }).catch(function (e) { Q.message(msg, e.message); go.disabled = false; }); });
    body.appendChild(el('p', { text: explain }));
    if (offerCsv) body.appendChild(el('p', {}, [el('button', { type: 'button', class: 'secondary small', text: 'Download CSV first', onclick: downloadCsv })]));
    body.appendChild(el('label', { text: 'Type DELETE to confirm' }));
    body.appendChild(input);
    body.appendChild(el('div', { class: 'row mt' }, [go]));
    body.appendChild(msg);
    $('dlg').showModal(); input.focus();
  }

  function deleteAll() {
    if (classFilter === 'all') return Q.message($('dash-msg'), 'Choose one class in the Class menu first.');
    var c = BP.classes.find(function (x) { return String(x.id) === classFilter; });
    typedConfirm('Delete all ' + paperInfo().name + ' results for ' + c.name,
      'This removes every ' + paperInfo().name + ' submission for ' + c.name + ' (' + data.students.length + ' students). Other papers and classes are not affected. A backup copy stays in the submission log.',
      function () { return Q.api('/api/teacher/delete-all', { method: 'POST', body: { paper: paper, classId: c.id, confirm: 'DELETE' } }).then(function () { refreshClasses(); loadResults(); }); }, true);
  }

  // ------------------------------------------------------------ classes
  function refreshClasses() {
    return Q.api('/api/teacher/classes').then(function (r) { BP.classes = r.classes; fillClassFilter(); renderClasses(); });
  }
  function classAction(c, action, body) {
    return Q.api('/api/teacher/classes/' + c.id + '/' + action, { method: 'POST', body: body || {} }).then(function (r) { BP.classes = r.classes; fillClassFilter(); renderClasses(); });
  }
  function renderClasses() {
    var t = Q.clear($('class-table'));
    t.appendChild(el('thead', {}, [el('tr', {}, ['Class', 'Code', 'Status', 'Submissions', ''].map(function (h) { return el('th', { text: h }); }))]));
    var tb = el('tbody');
    BP.classes.forEach(function (c) {
      var code = el('code', { class: 'code', text: '••••••' });
      var showBtn = el('button', { type: 'button', class: 'ghost small', text: 'Show' });
      showBtn.addEventListener('click', function () { var hidden = code.textContent !== c.code; code.textContent = hidden ? c.code : '••••••'; showBtn.textContent = hidden ? 'Hide' : 'Show'; });
      var copyBtn = el('button', { type: 'button', class: 'ghost small', text: 'Copy' });
      copyBtn.addEventListener('click', function () {
        (navigator.clipboard ? navigator.clipboard.writeText(c.code) : Promise.reject()).then(function () { copyBtn.textContent = 'Copied'; setTimeout(function () { copyBtn.textContent = 'Copy'; }, 1500); })
          .catch(function () { code.textContent = c.code; });
      });
      var regen = el('button', { type: 'button', class: 'secondary small', text: 'New code' });
      regen.addEventListener('click', function () { if (window.confirm('Make a new code for ' + c.name + '? The old code will stop working.')) classAction(c, 'regenerate').catch(showClassErr); });
      var toggle = el('button', { type: 'button', class: 'secondary small', text: c.open ? 'Close' : 'Open' });
      toggle.addEventListener('click', function () { classAction(c, c.open ? 'close' : 'open').catch(showClassErr); });
      var delRes = el('button', { type: 'button', class: 'danger small', text: 'Delete results', disabled: !c.submissions });
      delRes.addEventListener('click', function () {
        typedConfirm('Delete all results for ' + c.name, 'This removes every submission (all three papers) for ' + c.name + '. The class and its code stay.', function () { return classAction(c, 'delete-results', { confirm: 'DELETE' }).then(loadResults); }, false);
      });
      var delCls = el('button', { type: 'button', class: 'ghost small', text: 'Remove class' });
      delCls.addEventListener('click', function () {
        typedConfirm('Remove class ' + c.name, 'This removes the class, its code and all of its results.', function () { return classAction(c, 'delete', { confirm: 'DELETE' }).then(loadResults); }, false);
      });
      tb.appendChild(el('tr', {}, [
        el('td', {}, [el('b', { text: c.name })]), el('td', {}, [el('div', { class: 'row' }, [code, showBtn, copyBtn])]),
        el('td', {}, [el('span', { class: 'badge ' + (c.open ? 'open' : 'closed'), text: c.open ? 'Open' : 'Closed' })]),
        el('td', { class: 'num', text: c.submissions }), el('td', {}, [el('div', { class: 'row' }, [regen, toggle, delRes, delCls])]),
      ]));
    });
    t.appendChild(tb);
  }
  function showClassErr(e) { if (!onAuthError(e)) Q.message($('class-msg'), e.message); }
  function addClass() {
    var name = $('new-class').value.trim();
    if (!name) return Q.message($('class-msg'), 'Type a class name first.');
    Q.api('/api/teacher/classes', { method: 'POST', body: { name: name } }).then(function (r) {
      BP.classes = r.classes; $('new-class').value = ''; Q.message($('class-msg'), ''); fillClassFilter(); renderClasses();
    }).catch(showClassErr);
  }

  // ------------------------------------------------------------ settings
  function renderBounds() {
    $('bound-note').textContent = BP.boundaryNote;
    var t = Q.clear($('bounds'));
    var grades = BP.defaultBoundaries.map(function (b) { return b.grade; });
    t.appendChild(el('thead', {}, [el('tr', {}, [el('th', { text: 'Paper' })].concat(grades.map(function (g) { return el('th', { text: g + ' (%)' }); })))]));
    var tb = el('tbody');
    BP.papers.forEach(function (p) {
      tb.appendChild(el('tr', {}, [el('td', { text: p.name })].concat(BP.boundaries[p.id].map(function (b, i) {
        return el('td', {}, [el('input', { type: 'number', min: 0, max: 100, step: 0.5, value: b.pct, 'data-paper': p.id, 'data-i': i, 'aria-label': p.name + ' ' + b.grade + ' boundary' })]);
      }))));
    });
    t.appendChild(tb);
  }
  function saveBounds() {
    var b = {};
    BP.papers.forEach(function (p) { b[p.id] = BP.boundaries[p.id].map(function (x) { return { grade: x.grade, pct: x.pct }; }); });
    Array.prototype.forEach.call(document.querySelectorAll('#bounds input'), function (inp) { b[inp.getAttribute('data-paper')][Number(inp.getAttribute('data-i'))].pct = Number(inp.value); });
    postBounds({ boundaries: b });
  }
  function postBounds(body) {
    Q.api('/api/teacher/settings', { method: 'POST', body: body }).then(function (r) {
      BP.boundaries = r.boundaries; renderBounds(); Q.message($('bound-msg'), 'Saved. Grades have been updated.', 'ok');
    }).catch(function (e) { if (!onAuthError(e)) Q.message($('bound-msg'), e.message, 'error'); });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
