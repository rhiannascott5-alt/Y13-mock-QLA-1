declare module '*.html' { const s: string; export default s; }
declare module '*.css' { const s: string; export default s; }
declare module '*.client.js' { const s: string; export default s; }
