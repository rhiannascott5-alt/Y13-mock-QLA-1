import { BLUEPRINT, Question } from './data';

export type Boundaries = Record<string, { grade: string; pct: number }[]>;

export const PAPER_IDS = BLUEPRINT.papers.map((p) => p.id);

export function questionsFor(paper: string): Question[] {
  return BLUEPRINT.questions.filter((q) => q.paper === paper);
}

export function defaultBoundaries(): Boundaries {
  const b: Boundaries = {};
  for (const p of BLUEPRINT.papers) b[p.id] = BLUEPRINT.defaultBoundaries.map((x) => ({ ...x }));
  return b;
}

/** Validate a boundaries object sent by the teacher. Returns a clean copy or an error string. */
export function cleanBoundaries(input: unknown): Boundaries | string {
  if (!input || typeof input !== 'object') return 'Boundaries missing.';
  const out: Boundaries = {};
  const grades = BLUEPRINT.defaultBoundaries.map((b) => b.grade);
  for (const p of PAPER_IDS) {
    const list = (input as Record<string, unknown>)[p];
    if (!Array.isArray(list) || list.length !== grades.length) return `Boundaries for ${p} are incomplete.`;
    const clean: { grade: string; pct: number }[] = [];
    for (let i = 0; i < grades.length; i++) {
      const item = list[i] as { grade?: unknown; pct?: unknown };
      const pct = Number(item?.pct);
      if (item?.grade !== grades[i] || !Number.isFinite(pct) || pct < 0 || pct > 100) return `Boundary ${grades[i]} for ${p} must be a percentage from 0 to 100.`;
      if (i > 0 && pct > clean[i - 1].pct) return `For ${p}, ${grades[i]} must not be higher than ${grades[i - 1]}.`;
      clean.push({ grade: grades[i], pct: Math.round(pct * 10) / 10 });
    }
    out[p] = clean;
  }
  return out;
}

/** Validate a student's marks for one paper. Returns label->mark or an error string. */
export function validateMarks(paper: string, input: unknown): Record<string, number> | string {
  if (!PAPER_IDS.includes(paper)) return 'Unknown paper.';
  if (!input || typeof input !== 'object' || Array.isArray(input)) return 'Marks missing.';
  const raw = input as Record<string, unknown>;
  const qs = questionsFor(paper);
  const allowed = new Set(qs.map((q) => q.label));
  for (const k of Object.keys(raw)) if (!allowed.has(k)) return `Unexpected question ${k}.`;
  const out: Record<string, number> = {};
  for (const q of qs) {
    const v = raw[q.label];
    if (v === undefined || v === null || v === '') return `Please enter a mark for question ${q.label}.`;
    const n = typeof v === 'number' ? v : Number(v);
    if (!Number.isInteger(n) || n < 0 || n > q.marks) return `Question ${q.label}: the mark must be a whole number from 0 to ${q.marks}.`;
    out[q.label] = n;
  }
  return out;
}

export function gradeFor(pct: number, bounds: { grade: string; pct: number }[]): string {
  for (const b of bounds) if (pct >= b.pct) return b.grade;
  return 'U';
}

export interface TopicResult { code: string; spec: string; name: string; got: number; max: number; pct: number; rag: 'green' | 'amber' | 'red' }
export interface TodoItem { kind: 'topic' | 'question'; text: string; detail: string }
export interface PaperResult { paper: string; paperName: string; total: number; max: number; pct: number; grade: string; topics: TopicResult[]; todo: TodoItem[] }

export function rag(pct: number): 'green' | 'amber' | 'red' {
  return pct >= 70 ? 'green' : pct >= 40 ? 'amber' : 'red';
}

export function analyse(paper: string, marks: Record<string, number>, bounds: Boundaries): PaperResult {
  const qs = questionsFor(paper);
  const p = BLUEPRINT.papers.find((x) => x.id === paper)!;
  let total = 0;
  const t = new Map<string, { got: number; max: number }>();
  for (const q of qs) {
    const got = marks[q.label] ?? 0;
    total += got;
    const e = t.get(q.topic) ?? { got: 0, max: 0 };
    e.got += got; e.max += q.marks; t.set(q.topic, e);
  }
  const pct = Math.round((1000 * total) / p.max) / 10;
  const topics: TopicResult[] = [];
  for (const tp of BLUEPRINT.topics) {
    const e = t.get(tp.code);
    if (!e) continue;
    const tpct = Math.round((1000 * e.got) / e.max) / 10;
    topics.push({ code: tp.code, spec: tp.spec, name: tp.name, got: e.got, max: e.max, pct: tpct, rag: rag(tpct) });
  }
  return { paper, paperName: p.name, total, max: p.max, pct, grade: gradeFor(pct, bounds[paper] ?? defaultBoundaries()[paper]), topics, todo: buildTodo(qs, marks, topics) };
}

/** To-do list: weakest topics first (below 70%), then the question parts where most marks were lost. */
export function buildTodo(qs: Question[], marks: Record<string, number>, topics: TopicResult[]): TodoItem[] {
  const todo: TodoItem[] = [];
  const weak = topics.filter((t) => t.pct < 70).sort((a, b) => a.pct - b.pct).slice(0, 4);
  for (const t of weak) {
    todo.push({
      kind: 'topic',
      text: `Revise ${t.name}`,
      detail: `Spec ${t.spec}: you scored ${t.got}/${t.max} (${t.pct}%).${t.rag === 'red' ? ' Priority topic.' : ''}`,
    });
  }
  const topicName = new Map(BLUEPRINT.topics.map((t) => [t.code, t.name]));
  const lost = qs
    .map((q) => ({ q, lost: q.marks - (marks[q.label] ?? 0) }))
    .filter((x) => x.lost > 0 && !x.q.mcq)
    .sort((a, b) => b.lost - a.lost || b.q.marks - a.q.marks)
    .slice(0, 6);
  for (const x of lost) {
    todo.push({
      kind: 'question',
      text: `Redo question ${x.q.label}`,
      detail: `You dropped ${x.lost} of ${x.q.marks} mark${x.q.marks === 1 ? '' : 's'} (${topicName.get(x.q.topic)}). Check it against the mark scheme.`,
    });
  }
  const wrongMcq = qs.filter((q) => q.mcq && (marks[q.label] ?? 0) === 0).map((q) => q.label);
  if (wrongMcq.length) {
    todo.push({
      kind: 'question',
      text: `Review the multiple-choice questions you got wrong`,
      detail: `Questions ${wrongMcq.join(', ')}. Work out why the correct answer is right.`,
    });
  }
  return todo;
}

export function cleanName(v: unknown): string | null {
  if (typeof v !== 'string') return null;
  const s = v.normalize('NFC').replace(/[\u0000-\u001f\u007f<>]/g, '').replace(/\s+/g, ' ').trim();
  if (s.length < 2 || s.length > 60) return null;
  return s;
}
